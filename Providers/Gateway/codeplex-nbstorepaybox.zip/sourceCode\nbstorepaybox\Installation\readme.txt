﻿Installation of PayBox Payment Provider for NB_Store
----------------------------------------------------

Step1 - Install Gateway Provider Install package as a normal module in DNN.

Step2 - Update the "gatewayproviders.xml" found in the "/DesktopModules/NB_Store" directory.

	Add xml Reference Node of:
		
		<gateway ref="PayBox">
			<name>PayBox</name>
			<assembly>NEvoweb.DNN.Modules.NB_Store.GatewayPayBox</assembly>
			<class>NEvoWeb.Modules.NB_Store.Gateway.GatewayPayBox</class>
		</gateway>
		
Example:-

<?xml version="1.0" encoding="utf-8" ?>
<root>
  <gateways>  
  <gateway ref="SIPS">
    <name>SIPS</name>
    <assembly>NEvoweb.DNN.Modules.NB_Store.GatewaySIPS</assembly>
    <class>NEvoWeb.Modules.NB_Store.Gateway.GatewaySIPS</class>
  </gateway>
    <gateway ref="Paypal">
      <name>Paypal</name>
      <assembly>NEvoweb.DNN.Modules.NB_Store.GatewayPayPal</assembly>
      <class>NEvoWeb.Modules.NB_Store.Gateway.GatewayPayPal</class>
    </gateway>
    <gateway ref="PayBox">
      <name>PayBox</name>
      <assembly>NEvoweb.DNN.Modules.NB_Store.GatewayPayBox</assembly>
      <class>NEvoWeb.Modules.NB_Store.Gateway.GatewayPayBox</class>
    </gateway>
  </gateways>
</root>


Step 3 - Create a payment gateway setting call "PayBox.gateway" and enter the settings needed.  
			For a full explaination of the PayVBox settings refer to the paybox documentation.
	
Eample:-

<root>
        <PBX_MODE>4</PBX_MODE>
        <PBX_SITE>1999888</PBX_SITE>
        <PBX_RANG>99</PBX_RANG>
        <PBX_DEVISE>978</PBX_DEVISE>
        <PBX_TOTAL>[ORDERAMOUNT]</PBX_TOTAL>
        <PBX_IDENTIFIANT>2</PBX_IDENTIFIANT>
        <PBX_CMD>[TRANSID]</PBX_CMD>
        <PBX_PORTEUR>[CUSTOMEREMAIL]</PBX_PORTEUR>
        <PBX_RETOUR>maref:R;auto:A;erreur:E</PBX_RETOUR>
        <PBX_EFFECTUE>http://www.MyWebsite.com/Cart/tabid/56/stg/5/Default.aspx</PBX_EFFECTUE>
        <PBX_REFUSE>http://www.MyWebsite.com/Cart/tabid/56/stg/5/Default.aspx</PBX_REFUSE>
        <PBX_ANNULE>http://www.MyWebsite.com/Cart/tabid/56/stg/5/Default.aspx</PBX_ANNULE>
	<PBX_REPONDRE_A>http://www.MyWebsite.com/Cart/tabid/56/stg/4/Default.aspx</PBX_REPONDRE_A>
        <ButtonImageURL>/Desktopmodules/NB_Store_GatewayPayBox/PayboxPaiementSecurise.gif</ButtonImageURL>
        <execpath>E:\Website\Desktopmodules\NB_Store_GatewayPayBox\modulev3_windows.exe</execpath>
</root>

Step 4 - The PayBox html code generator api "modulev3_windows.exe" is automatically placed in the module directory.
		 This can be updated or moved if you wish.
		 
		 In the "PayBox.gateway" setting you will need to specify the full path to the api in the <execpath> node.

Step 5 - Select the Payment Provider in the Checkout module settings.

Step 6 - In the DNN menu "Host>Host Settings", click on "Restart Application".  This will clear the cache and ensure the new provider is used.


******************************************************************************************************
*** NOTE: Step 7 - "utl http" option in the paybox admin has been replaced by the <PBX_REPONDRE_A> param.
******************************************************************************************************
Step 7 - The PayBox automatic response url "url http", must be set to something simular to:
http://www.MyWebsite.com/Cart/tabid/56/stg/4/Default.aspx








