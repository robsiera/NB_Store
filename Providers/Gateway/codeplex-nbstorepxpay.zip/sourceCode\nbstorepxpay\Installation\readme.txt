Installation of PxPay Payment Provider for NB_Store
----------------------------------------------------

Step1 - Install Gateway Provider Install package as a normal module in DNN.

Step2 - Update the "gatewayproviders.xml" found in the "/DesktopModules/NB_Store" directory.

	Add xml Reference Node of:
		
		<gateway ref="PxPay">
			<name>PxPay</name>
			<assembly>NEvoweb.DNN.Modules.NB_Store.GatewayPxPay</assembly>
			<class>NEvoWeb.Modules.NB_Store.Gateway.GatewayPxPay</class>
		</gateway>
		
Example:-

<?xml version="1.0" encoding="utf-8" ?>
<root>
  <gateways>  
  <gateway ref="SIPS">
    <name>SIPS</name>
    <assembly>NEvoweb.DNN.Modules.NB_Store.GatewaySIPS</assembly>
    <class>NEvoWeb.Modules.NB_Store.Gateway.GatewaySIPS</class>
  </gateway>
    <gateway ref="Paypal">
      <name>Paypal</name>
      <assembly>NEvoweb.DNN.Modules.NB_Store.GatewayPayPal</assembly>
      <class>NEvoWeb.Modules.NB_Store.Gateway.GatewayPayPal</class>
    </gateway>
	<gateway ref="PxPay">
		<name>PxPay</name>
		<assembly>NEvoweb.DNN.Modules.NB_Store.GatewayPxPay</assembly>
		<class>NEvoWeb.Modules.NB_Store.Gateway.GatewayPxPay</class>
	</gateway>
	</gateways>
</root>


Step 3 - Create a payment gateway setting call "PxPay.gateway" and enter the settings needed.  
			For a full explaination of the PxPay settings refer to the PxPay documentation.
	
Eample:-

<root>
	<paymentURL>https://sec.paymentexpress.com/pxpay/pxaccess.aspx</paymentURL>
	<PaymentExpress.PxPay>https://www.paymentexpress.com/pxpay/pxaccess.aspx</PaymentExpress.PxPay>
	<PxPayUserId></PxPayUserId>
	<PxPayKey></PxPayKey>
	<ButtonImageURL>/Desktopmodules/NB_Store_GatewayPxPay/pxpay.jpg</ButtonImageURL>
	<ReturnURL>http://www.MyWebsite.com/Cart/tabid/56/stg/5/PxPayExit/RETURN/Default.aspx</ReturnURL>
	<ReturnCancelURL>http://www.MyWebsite.com/Cart/tabid/56/stg/5/PxPayExit/CANCEL/Default.aspx</ReturnCancelURL>
	<MerchantLanguage>fr</MerchantLanguage>
	 <InputCurrency>NZD</InputCurrency>
	 <TxnType>Purchase</TxnType>
	 <MerchantReference>Test Transaction</MerchantReference>
</root>

Step 4 - Select the Payment Provider in the Checkout module settings.

Step 5 - In the DNN menu "Host>Host Settings", click on "Restart Application".  This will clear the cache and ensure the new provider is used.


NOTES:

Test credit Card number: 4111111111111111





