﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("nbs2 paypal")>
<Assembly: AssemblyDescription("nbs2 paypal")>
<Assembly: AssemblyCompany("Nevoweb")>
<Assembly: AssemblyProduct("nbs2 paypal")>
<Assembly: AssemblyCopyright("Nevoweb")>
<Assembly: AssemblyTrademark("NWB")>

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("735596b1-8e9a-4af2-9dc1-a60023693096")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:

<Assembly: AssemblyVersion("3.0.0.3")>
<Assembly: AssemblyFileVersion("3.0.0.3")>
